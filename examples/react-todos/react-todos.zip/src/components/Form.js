import React, { Component } from 'react'

class Form extends Component {
    constructor(props) {
        super(props);
        this.state = {text: 'zhopa'};
        this.handleNoteAdd = this.handleNoteAdd.bind(this)
    }

    handleNoteAdd(){
        this.setState({
            text : 'asdfasd'
        });
    }
    render() {
        const {  text } = this.state
        return (
            <div>
                <input type="text"/>
                <button className="add-button" onClick={this.handleNoteAdd}>Add</button>
                {text}
            </div>
        );
    }
}

export default Form;
