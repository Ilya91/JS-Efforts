import React from 'react'

const Item = () => (
    <p>
        task
    </p>
)

export default Item
