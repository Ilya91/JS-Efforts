import React, { Component } from 'react'
import Item from './Item'

class List extends Component {
    constructor(props) {
        super(props)
        this.state = {items: []}
    }

    render(){
        const {  items } = this.state
        return (
            <div>
                {
                    (items.length) ?
                        items.map((item, i) =>
                            <Item key={i}/>
                        ): <p>no tasks</p>
                }
                <Item/>
            </div>
        )
    }

}

export default List
