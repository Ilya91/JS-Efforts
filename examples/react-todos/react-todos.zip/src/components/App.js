import React, { Component } from 'react'
import Form from './Form'
import Filter from './Filter'
import List from './List'

class App extends Component
{
    render() {
        return (
            <div>
                <Form/>
                <Filter/>
                <List/>
            </div>
        );
    }

}

export default App
