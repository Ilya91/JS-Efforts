import React from 'react'

const Filter = () => (
    <div>
        <a href="">All</a>,
        <a href="">Active</a>,
        <a href="">Completed</a>
    </div>
)

export default Filter
