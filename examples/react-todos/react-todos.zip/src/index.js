import React from 'react'
import App from './components/App'
import { render } from 'react-dom'

render(
  <div>
    <App/>
  </div>,
  document.getElementById('root')
)
